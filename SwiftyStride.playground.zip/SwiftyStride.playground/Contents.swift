/*

-- SwiftyStride custom operators --
         by Alex Andrews

Twitter:    @leakywellington
Blog:       www.leakywellington.com
Apps:       www.tenkettles.com


Examples:
    0 .. 2 .. 10 -> [0,2,4,6,8,10]
    4 .. 4 ..<16 -> [4,8,12]

*/

infix operator .. {associativity left}
func .. (lhs: Int, rhs: Int) -> (Int,Int){
    return (lhs, rhs)
}
func .. (lhs: (Int,Int), rhs: Int) -> [Int]{
    return Array(lhs.0.stride(through: rhs, by: lhs.1))
}

infix operator ..< {associativity left}
func ..< (lhs: (Int,Int), rhs: Int) -> [Int]{
    return Array(lhs.0.stride(to: rhs, by: lhs.1))
}

print(0..2..10)
print(4..4..<16)



